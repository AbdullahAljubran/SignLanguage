class C3k2(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_5.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_8.Conv
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.ultralytics.nn.modules.block.C3k2,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    _0 = getattr(m, "0")
    cv1 = self.cv1
    _1 = (cv1).forward(argument_1, argument_2, )
    _2 = torch.split_with_sizes(_1, [32, 32], 1)
    _3, input, = _2
    _4 = [_3, input, (_0).forward(argument_1, input, )]
    input0 = torch.cat(_4, 1)
    return (cv2).forward(argument_1, input0, )
class Bottleneck(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_11.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_14.Conv
  def forward(self: __torch__.ultralytics.nn.modules.block.Bottleneck,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    input: Tensor) -> Tensor:
    cv2 = self.cv2
    cv1 = self.cv1
    _4 = (cv2).forward(argument_1, (cv1).forward(argument_1, input, ), )
    return torch.add(input, _4)
class C3k(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_44.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_47.Conv
  cv3 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_50.Conv
  m : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.ultralytics.nn.modules.block.C3k,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    input: Tensor) -> Tensor:
    cv3 = self.cv3
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _5 = (m).forward(argument_1, (cv1).forward(argument_1, input, ), )
    _6 = [_5, (cv2).forward(argument_1, input, )]
    input1 = torch.cat(_6, 1)
    return (cv3).forward(argument_1, input1, )
class SPPF(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_105.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_108.Conv
  m : __torch__.torch.nn.modules.pooling.MaxPool2d
  def forward(self: __torch__.ultralytics.nn.modules.block.SPPF,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _7 = (cv1).forward(argument_1, argument_2, )
    _8 = (m).forward(_7, )
    _9 = (m).forward1(_8, )
    input = torch.cat([_7, _8, _9, (m).forward2(_9, )], 1)
    return (cv2).forward(argument_1, input, )
class C2PSA(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  cv1 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_111.Conv
  cv2 : __torch__.ultralytics.nn.modules.conv.___torch_mangle_114.Conv
  m : __torch__.torch.nn.modules.container.___torch_mangle_130.Sequential
  def forward(self: __torch__.ultralytics.nn.modules.block.C2PSA,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    argument_2: Tensor) -> Tensor:
    cv2 = self.cv2
    m = self.m
    cv1 = self.cv1
    _10 = (cv1).forward(argument_1, argument_2, )
    _11 = torch.split_with_sizes(_10, [256, 256], 1)
    a, x, = _11
    input = torch.cat([a, (m).forward(argument_1, x, )], 1)
    return (cv2).forward(argument_1, input, )
class PSABlock(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  attn : __torch__.ultralytics.nn.modules.block.Attention
  ffn : __torch__.torch.nn.modules.container.___torch_mangle_129.Sequential
  def forward(self: __torch__.ultralytics.nn.modules.block.PSABlock,
    argument_1: __torch__.torch.nn.modules.activation.___torch_mangle_286.SiLU,
    x: Tensor) -> Tensor:
    ffn = self.ffn
    attn = self.attn
    input = torch.add(x, (attn).forward(x, ))
    b = torch.add(input, (ffn).forward(argument_1, input, ))
    return b
class Attention(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  qkv : __torch__.ultralytics.nn.modules.conv.___torch_mangle_116.Conv
  proj : __torch__.ultralytics.nn.modules.conv.___torch_mangle_119.Conv
  pe : __torch__.ultralytics.nn.modules.conv.___torch_mangle_122.Conv
  def forward(self: __torch__.ultralytics.nn.modules.block.Attention,
    x: Tensor) -> Tensor:
    proj = self.proj
    pe = self.pe
    qkv = self.qkv
    B = ops.prim.NumToTensor(torch.size(x, 0))
    _12 = int(B)
    _13 = int(B)
    _14 = int(B)
    C = ops.prim.NumToTensor(torch.size(x, 1))
    _15 = int(C)
    _16 = int(C)
    H = ops.prim.NumToTensor(torch.size(x, 2))
    _17 = int(H)
    _18 = int(H)
    W = ops.prim.NumToTensor(torch.size(x, 3))
    _19 = int(W)
    _20 = int(W)
    N = torch.mul(H, W)
    _21 = int(N)
    _22 = torch.view((qkv).forward(x, ), [_14, 4, 128, _21])
    _23 = torch.split_with_sizes(_22, [32, 32, 64], 2)
    q, k, v, = _23
    _24 = torch.matmul(torch.transpose(q, -2, -1), k)
    attn = torch.mul(_24, CONSTANTS.c0)
    attn0 = torch.softmax(attn, -1)
    _25 = torch.matmul(v, torch.transpose(attn0, -2, -1))
    _26 = torch.view(_25, [_13, _16, _18, _20])
    input = torch.reshape(v, [_12, _15, _17, _19])
    input2 = torch.add(_26, (pe).forward(input, ))
    return (proj).forward(input2, )
class DFL(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.torch.nn.modules.conv.___torch_mangle_292.Conv2d
  def forward(self: __torch__.ultralytics.nn.modules.block.DFL,
    x: Tensor) -> Tensor:
    conv = self.conv
    b = ops.prim.NumToTensor(torch.size(x, 0))
    _27 = int(b)
    _28 = int(b)
    a = ops.prim.NumToTensor(torch.size(x, 2))
    _29 = int(a)
    _30 = torch.transpose(torch.view(x, [_28, 4, 16, int(a)]), 2, 1)
    input = torch.softmax(_30, 1)
    distance = torch.view((conv).forward(input, ), [_27, 4, _29])
    return distance
