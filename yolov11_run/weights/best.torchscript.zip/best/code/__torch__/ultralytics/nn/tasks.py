class DetectionModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  model : __torch__.torch.nn.modules.container.___torch_mangle_293.Sequential
  def forward(self: __torch__.ultralytics.nn.tasks.DetectionModel,
    x: Tensor) -> Tensor:
    model = self.model
    _23 = getattr(model, "23")
    model0 = self.model
    _22 = getattr(model0, "22")
    model1 = self.model
    _21 = getattr(model1, "21")
    model2 = self.model
    _20 = getattr(model2, "20")
    model3 = self.model
    _19 = getattr(model3, "19")
    model4 = self.model
    _18 = getattr(model4, "18")
    model5 = self.model
    _17 = getattr(model5, "17")
    model6 = self.model
    _16 = getattr(model6, "16")
    model7 = self.model
    _15 = getattr(model7, "15")
    model8 = self.model
    _14 = getattr(model8, "14")
    model9 = self.model
    _13 = getattr(model9, "13")
    model10 = self.model
    _12 = getattr(model10, "12")
    model11 = self.model
    _11 = getattr(model11, "11")
    model12 = self.model
    _10 = getattr(model12, "10")
    model13 = self.model
    _9 = getattr(model13, "9")
    model14 = self.model
    _8 = getattr(model14, "8")
    model15 = self.model
    _7 = getattr(model15, "7")
    model16 = self.model
    _6 = getattr(model16, "6")
    model17 = self.model
    _5 = getattr(model17, "5")
    model18 = self.model
    _4 = getattr(model18, "4")
    model19 = self.model
    _3 = getattr(model19, "3")
    model20 = self.model
    _2 = getattr(model20, "2")
    model21 = self.model
    _1 = getattr(model21, "1")
    model22 = self.model
    _230 = getattr(model22, "23")
    cv3 = _230.cv3
    _24 = getattr(cv3, "2")
    _110 = getattr(_24, "1")
    _111 = getattr(_110, "1")
    act = _111.act
    model23 = self.model
    _0 = getattr(model23, "0")
    _25 = (_1).forward(act, (_0).forward(act, x, ), )
    _26 = (_3).forward(act, (_2).forward(act, _25, ), )
    _27 = (_4).forward(act, _26, )
    _28 = (_6).forward(act, (_5).forward(act, _27, ), )
    _29 = (_8).forward(act, (_7).forward(act, _28, ), )
    _30 = (_10).forward(act, (_9).forward(act, _29, ), )
    _31 = (_12).forward((_11).forward(_30, ), _28, )
    _32 = (_13).forward(act, _31, )
    _33 = (_15).forward((_14).forward(_32, ), _27, )
    _34 = (_16).forward(act, _33, )
    _35 = (_18).forward((_17).forward(act, _34, ), _32, )
    _36 = (_19).forward(act, _35, )
    _37 = (_21).forward((_20).forward(act, _36, ), _30, )
    _38 = (_23).forward(_34, _36, (_22).forward(act, _37, ), )
    return _38
